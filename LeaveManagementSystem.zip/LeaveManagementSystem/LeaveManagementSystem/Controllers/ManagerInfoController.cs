﻿using LeaveManagementSystem.Models;
using LeaveManagementSystem.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerInfoController : ControllerBase
    {
        private readonly IManager imanager;

        public ManagerInfoController(IManager imanager)
        {
            this.imanager = imanager;
        }
        [HttpGet]
        [Route("login/{Mngid}/{Password}")]
        public  IActionResult Login(int Mngid,string Password)
        {
            var ar =  imanager.Login(Mngid, Password);
            if(ar!=null)
            {
                return Ok(ar);
            }
            return NotFound();

        }
        [HttpPost]
        [Route("Addmanager")]
        public async Task<IActionResult> AddManager(ManagerModel manager)
        {
            var a = await imanager.AddManager(manager);
           
            return Ok(a);
        }
       
       
        [HttpPut]
        [Route("updatemanager")]
        public async Task<IActionResult> UpdateManager(int Mngid,ManagerModel manager)
        {
            var a = await imanager.UpdateManager(Mngid,manager);
            return Ok(a);
        }
        [HttpGet]
        [Route("getmanager/{Mngid}")]
        public async Task<IActionResult> GetManagerbyid(int Mngid)
        {
            var a = await imanager.GetManagerByID(Mngid);
            return Ok(a);
        }
        [HttpDelete]
        [Route("delete/{Mngid}")]
        public async Task<IActionResult> DeleteManager(int Mngid)
        {
            var a = await imanager.DeleteManager(Mngid);
            return Ok(a);
        }
        [HttpGet]
        [Route("showallmanager")]
        public async Task<IActionResult> ShowAll()
        {
            var a = await imanager.ShowAllManagers();
            return Ok(a);
        }
        [HttpGet]
        [Route("Myreporting")]
        public async Task<IActionResult> MyReporting()
        {
            var a = await imanager.MyReporting();
            return Ok(a);
        }
    }

}
