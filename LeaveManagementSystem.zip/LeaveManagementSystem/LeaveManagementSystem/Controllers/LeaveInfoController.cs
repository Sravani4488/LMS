﻿using LeaveManagementSystem.Models;
using LeaveManagementSystem.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using LeaveManagementSystem.DBConnect;

namespace LeaveManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveInfoController : ControllerBase
    {
        private readonly ILeave ileave;
        private readonly LMSDbcontext lMSDbcontext;

        public LeaveInfoController(ILeave ileave, LMSDbcontext lMSDbcontext)
        {
            this.ileave = ileave;
            this.lMSDbcontext = lMSDbcontext;
        }
        [HttpPost]
        [Route("apply")]
        public async Task<IActionResult> Applyleave(LeaveModel leavemodel)
        {
            bool b = await ileave.ApplyLeave(leavemodel);
            return Ok(b);

        }
        [HttpGet]
        [Route("leave/{id}")]

        public async Task<IActionResult> Viewleave(int id)
        {
            LeaveModel b = await ileave.ViewLeave(id);
            return Ok(b);
        }

        

        //[HttpPost]
        //[Route("action")]
        //public async Task<IActionResult> LeaveAction(int id, LeaveModel leaveModel)
        //{
        //    var a = await ileave.LeaveAction(id, leaveModel);
        //    return Ok(a);
        //}

        [HttpPost]
        [Route("updatebalance")]
        public async Task<IActionResult> UpdateBalance(int id, EmployeeModel employeeModel)
        {
            var a = await ileave.UpdateBalance(id, employeeModel);
            return Ok(a);
        }


        [HttpPut]
        [Route("leave/approve/{id}")]
        public async Task<IActionResult> Approve(int id, LeaveModel leaveModel)
        {
            var a = await ileave.ApproveDeny(id, leaveModel);

            return Ok(a);
        }
        [HttpPut]
        [Route("updateleave")]
        public async Task<IActionResult> Updateleave(int id,LeaveModel leave)
        {
            if(leave.Status=="Approve")
            {
                var ar = await ileave.GetEmployeeByID(leave.EmployeeId);
                if(ar.Availabledays>=leave.NoofDays)
                {
                    ar.Availabledays = ar.Availabledays - leave.NoofDays;
                    int res1 = await ileave.UpdateBalance(ar.EmpId, ar);
                    if(res1>0)
                    {
                        int res = await ileave.ApproveDeny(id, leave);
                        if(res>0)
                        {
                            return Ok(ar);
                        }
                        return NotFound();
                    }
                }
            }
            return NotFound();
        }

        [HttpGet]
        [Route("pendingleaves")]
        public async Task<IActionResult> pending()
        {
            var a = await ileave.pendingleave();
            if (a != null)
            {
                return Ok(a);
            }
            return NotFound();

        }
        [HttpGet]
        [Route("approvedleaves")]
        public async Task<IActionResult> approvedleaves()
        {
            var a = await ileave.approvedleave();
            if (a != null)
            {
                return Ok(a);
            }
            return NotFound();

        }
    }




}
