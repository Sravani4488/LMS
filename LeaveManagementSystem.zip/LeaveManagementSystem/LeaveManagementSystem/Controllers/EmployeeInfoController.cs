﻿using LeaveManagementSystem.Models;
using LeaveManagementSystem.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeInfoController : ControllerBase
    {
        private readonly IEmployee iemployee;

        public EmployeeInfoController(IEmployee iemployee)
        {
            this.iemployee = iemployee;
        }
        [HttpGet]
        [Route("login/{empid}/{password}")]
        public IActionResult Login(int empid,string password)
        {
           var ar = iemployee.Login(empid, password);
            if(ar!=null)
            {
                return Ok(ar);
            }
            return NotFound();
        }
        [HttpGet]
        [Route("details/{Empid}")]
        public async Task<IActionResult> GetEmployeebyId(int Empid)
        {
            EmployeeModel emp = await iemployee.GetEmployeeByID(Empid);
            return Ok(emp);

        }
        [HttpPost]
        [Route("Add")]
        public async Task<IActionResult> AddEmployee(EmployeeModel employee)
        {
            var a = await iemployee.AddEmployee(employee);
            return Ok(a);
        }
        [HttpPut]
        [Route("update/{empid}")]
        public async Task<IActionResult> UpdateEmployee(int empid,EmployeeModel employee)
        {
            var a = await iemployee.UpdateEmployee(empid, employee);
            return Ok(a);
        }
        [HttpDelete]
        [Route("delete/{empid}")]
        public async Task<IActionResult> DeleteEmployee(int empid)
        {
            var a = await iemployee.DeleteEmployee(empid);
            return Ok(a);
        }
        [HttpGet]
        [Route("mngdetails")]
        public async Task<IActionResult> managerdetails(int mngid)
        {
            ManagerModel mng = await iemployee.My_Manager(mngid);
            return Ok(mng);
        }
        [HttpGet]
        [Route("myapplication")]
        public async Task<IActionResult> myapplication(int empid)
        {
            var a = await iemployee.My_Application(empid);
            return Ok(a);
        }
        [HttpGet]
        [Route("showallemployee")]
        public async Task<IActionResult> Showallemployee()
        {
            var a = await iemployee.ShowAllEmployees();
            return Ok(a);
        }
        [HttpPut]
        [Route("password/{empid}")]
        public async Task<IActionResult> updatepassword(int empid,EmployeeModel employee)
        {
            var a = await iemployee.updatepassword(empid,employee);
            return Ok(a);
            
            
        }

    }
}
