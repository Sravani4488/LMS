﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Models
{
    public class EmployeeModel
    {
        [Required(ErrorMessage = "ID Required!")]
        [Key]
        public int EmpId { get; set; }

        [Required(ErrorMessage = "Name Required!")]
        [MaxLength(12)]
        public string EmpFullName{ get; set; }

        [Required(ErrorMessage = "Email Address Required!"), MinLength(1), EmailAddress(ErrorMessage = "Invalid Email Address"), MaxLength(50), Display(Name = "Email")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Invalid Email Address")]
        [RegularExpression("^[a-zA-Z0-9_\\.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$", ErrorMessage = "Invalid Email Address")]
        public string EmpEmailAddress  { get; set; }

        [Required(ErrorMessage = "Phone Number Required!")]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Phone Number")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public double EmpMobileNumber { get; set; }

        [Required(ErrorMessage = "DOJ Required")]
        [DataType(DataType.DateTime)]
        public DateTime EmpDoj { get; set; }

        [Required(ErrorMessage = "Deparment Required!")]
        public string Department { get; set; }

        [Required(ErrorMessage = "Password Required!")]
        [DataType(DataType.Password)]
        [StringLength(maximumLength: 20, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        public string Password { get; set; }

        [Required]
        public int Availabledays { get; set; }

        [Required]
        public int ManagerId { get; set; }
        [ForeignKey("ManagerId")]
        public virtual ManagerModel Manager { get; set; }
        
        

    }
}
