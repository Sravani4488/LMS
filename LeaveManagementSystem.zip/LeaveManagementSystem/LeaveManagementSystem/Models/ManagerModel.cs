﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Models
{
    public class ManagerModel
    {
        [Required]
        [Key]
        public int MngId { get; set; }
        [Required]
        public string MngFullName { get; set; }
        [Required]
        public string MngEmailAddress { get; set; }
        [Required]
        public double MngMobileNumber { get; set; }
        [Required]
        public string Password { get; set; }


    }
}
