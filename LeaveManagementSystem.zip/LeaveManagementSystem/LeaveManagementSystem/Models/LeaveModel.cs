﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Models
{
    public class LeaveModel
    {
        [Required]
        [Key]
        public int LeaveId { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
        [Required]
        public string LeaveType { get; set; }
        [Required]
        public int NoofDays { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public string Reason { get; set; }
        [Required]
        public DateTime AppliedOn { get; set; }
        [Required]
        public string ManagerComments { get; set; }
        [Required]
        public int EmployeeId { get; set; }
       
      
        [Required]
        public int ManagerId { get; set; }
        
       

      
    }
}
