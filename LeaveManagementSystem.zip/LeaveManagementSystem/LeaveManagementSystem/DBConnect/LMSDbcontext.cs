﻿using LeaveManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.DBConnect
{
    public class LMSDbcontext:DbContext
    {
        public LMSDbcontext(DbContextOptions<LMSDbcontext>options):base(options)
        {

        }
        public DbSet<EmployeeModel> Employees { get; set; }
        public DbSet<ManagerModel> Managers { get; set; }
        public DbSet<LeaveModel> Leave { get; set; }
    }
}
