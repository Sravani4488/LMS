﻿using LeaveManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Repository
{
    public interface ILeave
    {
        Task<bool> ApplyLeave(LeaveModel leavemodel);

        Task<LeaveModel> ViewLeave(int id);

        Task<int> UpdateBalance(int id, EmployeeModel employeeModel);

        Task<int> ApproveDeny(int id, LeaveModel leaveModel);

        Task<List<LeaveModel>> pendingleave();
        Task<List<LeaveModel>> approvedleave();
        Task<EmployeeModel> GetEmployeeByID(int empid);

    }
}
