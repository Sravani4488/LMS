﻿using LeaveManagementSystem.DBConnect;
using LeaveManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Repository
{
    public class Employee : IEmployee
    {
        private readonly LMSDbcontext lmsdb;

        public Employee(LMSDbcontext lmsdb)
        {
            this.lmsdb = lmsdb;
        }

        public EmployeeModel Login(int Empid,string Password)
        {
            EmployeeModel emp = lmsdb.Employees.Where(x => x.EmpId ==Empid && x.Password == Password).FirstOrDefault();
            return emp;
        }

        public async Task<List<LeaveModel>> My_Application(int empid)
        {
            var b = await lmsdb.Leave.Where(x => x.EmployeeId == empid).ToListAsync();
            return b;
            
        }
        public async Task<EmployeeModel> GetEmployeeByID(int empid)
        {
            var ar = await lmsdb.Employees.Where(x => x.EmpId == empid).FirstOrDefaultAsync();
            return ar;
        }
        public async Task<int> UpdateEmployee(int empid, EmployeeModel employee)
        {
            var ar = await lmsdb.Employees.Where(x => x.EmpId == empid).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.EmpFullName = employee.EmpFullName;
                ar.EmpEmailAddress = employee.EmpEmailAddress;
                ar.Department = employee.Department;
                ar.EmpMobileNumber = employee.EmpMobileNumber;
                ar.EmpDoj = employee.EmpDoj;
                await lmsdb.SaveChangesAsync();

            }
            return empid;
        }
        public async Task<int> AddEmployee(EmployeeModel employee)
        {
            lmsdb.Employees.Add(new EmployeeModel
            {
                EmpFullName = employee.EmpFullName,
                EmpEmailAddress = employee.EmpEmailAddress,
                Password = employee.Password,
                EmpDoj = employee.EmpDoj,
                Department = employee.Department,
                ManagerId = employee.ManagerId,
                EmpMobileNumber = employee.EmpMobileNumber,
                Availabledays = employee.Availabledays
            });
            await lmsdb.SaveChangesAsync();
            return employee.EmpId;
        }

       

        public async Task<ManagerModel> My_Manager(int Empid)
        {
            var ar = await lmsdb.Employees.Where(x => x.EmpId == Empid).FirstOrDefaultAsync();
            ManagerModel mg = await lmsdb.Managers.Where(x => x.MngId == ar.ManagerId).FirstOrDefaultAsync();
            return mg;
        }

        public  async Task<List<EmployeeModel>> ShowAllEmployees()
        {
            var ar = await lmsdb.Employees.ToListAsync();
            return ar;
        }

      
        public async Task<int> DeleteEmployee(int empid)
        {
            var ar = await lmsdb.Employees.Where(x => x.EmpId == empid).FirstOrDefaultAsync();
            if (ar != null)
            {
                lmsdb.Employees.Remove(ar);
                await lmsdb.SaveChangesAsync();
            }
            return empid;
        }

        public async Task<int> updatepassword(int empid,EmployeeModel employee)
        {
            var ar = await lmsdb.Employees.Where(x => x.EmpId == empid).FirstOrDefaultAsync();
            if(ar!=null)
            {
                ar.Password = employee.Password;
                await lmsdb.SaveChangesAsync();
            }
            return empid;
          
        }
    }
}
