﻿using LeaveManagementSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Repository
{
    public interface IEmployee
    {
        EmployeeModel Login(int Empid ,string Password);
        Task<int> updatepassword(int Empid,EmployeeModel employee);
        

        Task<ManagerModel> My_Manager(int Empid);

        Task<List<LeaveModel>> My_Application(int empid);
        Task<List<EmployeeModel>> ShowAllEmployees();
        Task<EmployeeModel> GetEmployeeByID(int empid);
        Task<int> AddEmployee(EmployeeModel employee);
        Task<int> UpdateEmployee(int empid, EmployeeModel employee);
        Task<int> DeleteEmployee(int empid);








    }
}
