﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LeaveManagementSystem.Models;

namespace LeaveManagementSystem.Repository
{
    public interface IManager
    {
       ManagerModel Login(int Mngid, string Password);

        Task<List<ManagerModel>> ShowAllManagers();
        Task<ManagerModel> GetManagerByID(int Mngid);
       
        Task<int> AddManager(ManagerModel manager);
        Task<int> UpdateManager(int Mngid,ManagerModel manager);
        Task<int> DeleteManager(int Mngid);
        Task<List<LeaveModel>> MyReporting();

    }
}
