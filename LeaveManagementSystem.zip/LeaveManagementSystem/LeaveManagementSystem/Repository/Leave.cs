﻿using LeaveManagementSystem.DBConnect;
using LeaveManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace LeaveManagementSystem.Repository
{
    public class Leave : ILeave
    {
        private readonly LMSDbcontext lMSDbContext;

        public Leave(LMSDbcontext lMSDbContext)
        {
            this.lMSDbContext = lMSDbContext;
        }


        public async Task<bool> ApplyLeave(LeaveModel leavemodel)
        {
            var ar = await lMSDbContext.Employees.Where(x => x.EmpId == leavemodel.EmployeeId).FirstOrDefaultAsync();
            if(leavemodel.NoofDays <= ar.Availabledays)
            {
                leavemodel.Status = "Pending";
                leavemodel.ManagerComments = "xxxxx";
                //ar.Availabledays = ar.Availabledays - leavemodel.NoofDays;
                lMSDbContext.Leave.Add(leavemodel);
                int res = await lMSDbContext.SaveChangesAsync();
                if (res > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;

        }

        public async Task<LeaveModel> ViewLeave(int id)
        {
            var ar = await lMSDbContext.Leave.Where(x => x.LeaveId == id).FirstOrDefaultAsync();
            return ar;
        }


       
        //public async Task<int> LeaveAction(int id, LeaveModel leaveModel)
        
        public async Task<int> ApproveDeny(int id, LeaveModel leaveModel)
        {
            var a = await lMSDbContext.Leave.Where(x => x.LeaveId == id).FirstOrDefaultAsync();
            if (a != null)
            {
                a.Status = leaveModel.Status;
                a.ManagerComments = leaveModel.ManagerComments;
                int res = await lMSDbContext.SaveChangesAsync();
                if (res > 0)
                {
                    return 1;
                }
                return 0;
            }
            return 0;
        }

        public async Task<int> UpdateBalance(int id, EmployeeModel employeeModel)
        {
            var ar = await lMSDbContext.Employees.Where(x => x.EmpId == id).FirstOrDefaultAsync();
            if(ar != null)
            {
                ar.Availabledays = employeeModel.Availabledays;
                int res = await lMSDbContext.SaveChangesAsync();
                if (res > 0)
                {
                    return 1;
                }
                return 0;
            }
            return 0;
        }
        public async Task<EmployeeModel> GetEmployeeByID(int empid)
        {
            var ar = await lMSDbContext.Employees.Where(x => x.EmpId == empid).FirstOrDefaultAsync();
            return ar;
        }

        public async Task<List<LeaveModel>> pendingleave()
        {
            var ar = await lMSDbContext.Leave.Where(x => x.Status == "Pending").ToListAsync();
            if(ar!=null)
            {
                return ar;
            }
            return ar;
        }

        public async Task<List<LeaveModel>> approvedleave()
        {
            var ar = await lMSDbContext.Leave.Where(x => x.Status == "Approve").ToListAsync();
            if (ar != null)
            {
                return ar;
            }
            return ar;
        }
    }
}
