﻿using LeaveManagementSystem.DBConnect;
using LeaveManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagementSystem.Repository
{
    public class Manager : IManager
    {
        private readonly LMSDbcontext LMSDbcontext;
        public Manager(LMSDbcontext LMSDbcontext)
        {
            this.LMSDbcontext = LMSDbcontext;
        }

        public async Task<int> DeleteManager(int Mngid)
        {
            var ar = await LMSDbcontext.Managers.Where(x => x.MngId == Mngid).FirstOrDefaultAsync();
            if (ar != null)
            {
                LMSDbcontext.Managers.Remove(ar);
                await LMSDbcontext.SaveChangesAsync();
            }
            return Mngid;
        }

        public async Task<ManagerModel> GetManagerByID(int Mngid)
        {
            var ar = await LMSDbcontext.Managers.Where(x => x.MngId == Mngid).FirstOrDefaultAsync();
            return ar;
        }
        
        public async Task<List<ManagerModel>> ShowAllManagers()
        {
            var ar = await LMSDbcontext.Managers.ToListAsync();
            return ar;
        }

        public async Task<int> UpdateManager(int Mngid,ManagerModel manager)
        {
            var ar = await LMSDbcontext.Managers.Where(x => x.MngId == Mngid).FirstOrDefaultAsync();
            if (ar != null)
            {
                ar.MngFullName = manager.MngFullName;
                ar.MngEmailAddress = manager.MngEmailAddress;
                ar.MngMobileNumber = manager.MngMobileNumber;
                ar.Password = manager.Password;
                await LMSDbcontext.SaveChangesAsync();

            }
            return Mngid;
        }

       

        public async Task<List<LeaveModel>> MyReporting()
        {
            var a = await LMSDbcontext.Leave.ToListAsync();
            return a;
        }

        public async Task<int> AddManager(ManagerModel manager)
        {
            LMSDbcontext.Managers.Add(new ManagerModel { MngFullName = manager.MngFullName, MngEmailAddress = manager.MngEmailAddress, MngMobileNumber = manager.MngMobileNumber, Password = manager.Password });
            await LMSDbcontext.SaveChangesAsync();
            return manager.MngId;
        }

        public ManagerModel Login(int Mngid, string Password)
        {
            ManagerModel mng = LMSDbcontext.Managers.Where(x => x.MngId == Mngid && x.Password == Password).FirstOrDefault();
            return mng;
        }
    }
}
