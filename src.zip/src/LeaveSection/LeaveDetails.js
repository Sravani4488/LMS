import React, { Component } from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import axios from 'axios';
import CurrDate from './CurrDate';
import { Link } from 'react-router-dom';
import DatePicker from 'react-datepicker';

export default class LeaveDetails extends Component {

  constructor() {
    super();
    this.state = {

      "employeeId": '',
      "managerId": '',
      "noofDays": '',
      "startDate":'',
      "endDate": '',
      "leaveType": "",
      "status": "",
      "reason": "",
      "appliedOn": "",
      "managerComments": "",
    }
    this.create = this.create.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  
  create() {
    // var g1 = new Date(this.state.startDate);
    // var g2 = new Date(this.state.endDate);
    // let g3 = new Date();
    // let g4 = new Date();
    // if (CurrDate("-")>=g1.getTime()){
    //   alert("Start date must be greater than current date");
    //   window.location = '/LeaveDetails'
    // }
    // else if (g2.getTime() >= g1.getTime())
    //   g4= new Date(g2)    

    const UserID = sessionStorage.getItem("empId");
    const ManagerID = sessionStorage.getItem("mngId");
    let data = {
      employeeId: UserID,
      managerId: ManagerID,
      noofDays: this.state.noofDays,
      startDate: this.state.startDate,
      endDate: this.state.endDate,
      leaveType: this.state.leaveType,
      status: "Pending",
      reason: this.state.reason,
      appliedOn: CurrDate("-"),
      managerComments: "NA"
    }

    axios.post("https://localhost:44328/api/LeaveInfo/apply", data
    ).then((response) => {
      console.log(response,data);
      alert("Leave applied successfully");

    })
      .catch((err) => {
        console.warn(err);
      })
  }

  handleChange(e) {
    this.setState(e);
  }


  render() {
    if(sessionStorage.UserName!=null){
      return (
        <>
        <div class="row justify-content-center row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4"row justify-content-center>
        <Form>

          <label><h1 >Apply Leave</h1></label>
          <Form.Group className="mb-3" controlId="formBasicStartDate">
            <Form.Label className='label'>From date</Form.Label>
            <Form.Control type="date" onChange={(e) => this.handleChange({ startDate: e.target.value })} placeholder="From date" />
            {/* <DatePicker wrapperClassName="datePicker" selected={this.state.startDate} onChange={this.handleChange} name='start_date' minDate={CurrDate("-")} /> */}
            <Form.Text className="text-muted">
              Enter the start date.
          </Form.Text>
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicEndDate">
            <Form.Label>To date</Form.Label>
            <Form.Control type="date" onChange={(e) => this.handleChange({ endDate: e.target.value })} placeholder="To date" />
            {/* <DatePicker className='react-datepicker__day--outside-month' selected={this.state.endDate} onChange={this.handleChange} name='end_date' minDate={CurrDate("-")} placeholderText="End Date"/> */}
            <Form.Text className="text-muted">
              Enter the End date.
          </Form.Text>
          </Form.Group>



          <Form.Group className="mb-3" controlId="formBasicnumber_of_Days">
            <Form.Label>number of Days</Form.Label>
            <Form.Control type="text" onChange={(e) => this.handleChange({ noofDays: e.target.value })} placeholder="number of Days" />

          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicReason">
            <Form.Label>Reason for leave</Form.Label>
            <Form.Control type="text" onChange={(e) => this.handleChange({ reason: e.target.value })} placeholder="Reason" />

          </Form.Group>

          <Form.Group className="mb-3" controlId="formBasicDropDown">
            <Form.Label>Select the type of leave </Form.Label>

            <select id="Leave" name="Leave" onChange={(e) => this.handleChange({ leaveType: e.target.value })}>
            <option value="Earned Leave">Choose</option>
              <option value="Earned Leave">Earned Leave</option>
              <option value="Maternity Leave">Maternity Leave</option>
              <option value="Sick Leave">Sick Leave</option>

            </select>
          </Form.Group>

          <Button variant="primary" onClick={()=>this.create()}>
            Apply Leave
        </Button>
        <br/><br/>
        <p> <Link as={Link} to="/EmployeeDashboard2">
        <Button variant="primary" type="Submit" >
            Back
        </Button>
        </Link></p>
        </Form >
        </div>
        </>
      )
    }else{
      alert("Please login first");
      window.location="/Login"
    }
  }
}
