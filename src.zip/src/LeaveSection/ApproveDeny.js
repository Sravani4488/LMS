import React, { Component } from 'react'
import Table from 'react-bootstrap/Table';
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import axios from 'axios'


export default class ApproveDeny extends Component {
  constructor(){
    super();
    this.state = {
      LeaveArr:[]
    }
  }
  logout(){
    sessionStorage.clear();
    window.location="/Login"
}
  componentDidMount(){
    const manager_Id = sessionStorage.getItem("mng");
    axios.get('https://localhost:44328/api/LeaveInfo/pendingleaves?mngId='+ manager_Id).then(Response=>{
        this.setState({LeaveArr:Response.data})
    }).catch(error=>{
       console.warn(error); 
    })
}
  render() {
    const {LeaveArr}=this.state;
    let mngFullName = sessionStorage.getItem("mngname")
    if(sessionStorage.mng != null){
    
      return (
        <>
        <header>
                        <div class="navbar navbar-dark bg-dark shadow-sm">
                            <div class="container">
                                <a href="#" class="navbar-brand d-flex align-items-center">
                                    <strong>Welcome, {mngFullName}</strong>
                                    
                                </a>
                                <p> <Card.Link as={Link} to="/Login">
                                <button class="navbar-toggler" onClick={this.logout} type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"> Logout
                                    {/* <span class="navbar-toggler-icon"></span> */}
                                </button>
                                </Card.Link>
                                </p>
                                
                            </div>
                        </div>
                    </header>
          <label><h1>Pending Applications</h1></label>
        <Table striped bordered hover variant="dark">
          <thead>
            <tr>
              <th>Leave ID</th>
              <th>From date</th>
              <th>To Date</th>
              <th>Leave Type</th>
              <th>Number of days</th>
              <th>Status</th>
              <th>Reason</th>
              <th>Applied on</th>
              <th>Manager comments</th>
              <th>Employee ID</th>
              <th>Manager ID</th>
              <th>Visit</th>
            </tr>
          </thead>
          <tbody>
          {
          LeaveArr.map(a=>
            <tr>
              <td>{a.leaveId}</td>
              <td>{a.startDate}</td>
              <td>{a.endDate}</td>
              <td>{a.leaveType}</td>
              <td>{a.noofDays}</td>
              <td>{a.status}</td>
              <td>{a.reason}</td>
              <td>{a.appliedOn}</td>
              <td>{a.managerComments}</td>
              <td>{a.employeeId}</td>
              <td>{a.managerId}</td>
              <td>
                <p> <Link to={"/ApproveDenyMgr/"+a.leaveId}>
                <button className="btn btn-outline-info mx-2">Click here</button>
                </Link></p>
              </td>
            </tr>
          )} 
          </tbody>
        </Table>
        <p> <Link as={Link} to="/ManagerDashboard">
          <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
          </Link></p>
        </>
      )
    }else{        
      alert("Please login first");
      window.location="/Login"
    }
  }
}
