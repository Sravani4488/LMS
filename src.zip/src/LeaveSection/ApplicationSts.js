import React, { Component } from 'react'
import Table from 'react-bootstrap/Table';
import axios from 'axios';
import { Link } from 'react-router-dom';



export default class ApplicationSts extends Component {
    constructor(){
        super();
        this.state={
            AppliedLeave:[]
        }
        
    }
    componentDidMount(){
        const empId = sessionStorage.getItem("empId");
        axios.get('https://localhost:44328/api/EmployeeInfo/myapplication?empid=' + empId).then(Response=>{
            this.setState({AppliedLeave:Response.data})
        }).catch(error=>{
           console.warn(error); 
        })
    }

   
    
    render() {
        const {AppliedLeave}=this.state;
        if(sessionStorage.UserName !=null){
            return (
                <>
              <label> <h1>My Applications</h1></label>
                <Table striped bordered hover variant="dark">
            <thead>
              <tr>
                <th>Employee ID</th>
                <th>Leave ID</th>
                <th>From Date</th>
                <th>To Date</th>
                <th>Leave Type</th>
                <th>Number of Days</th>
                <th>Status</th>
                <th>Reason</th>
                <th>Applied on</th>
                <th>Manager comments</th>
              </tr>
            </thead>
            <tbody>
                {
                    AppliedLeave.map(a=>
                        
                <tr>
                
                <td>{a.employeeId}</td>
                <td>{a.leaveId}</td>
                <td>{a.startDate}</td>
                <td>{a.endDate}</td>
                <td>{a.leaveType}</td>
                <td>{a.noofDays}</td>
                <td>{a.status}</td>
                <td>{a.reason}</td>
                <td>{a.appliedOn}</td>
                <td>{a.managerComments}</td>
                
              </tr>
                        
                )
                }
              
              
            </tbody>
            </Table>
            <p> <Link as={Link} to="/EmployeeDashboard2">
              <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
              </Link></p>
            </>
            )
        }else{
          alert("Please login first");
          window.location="/Login"
        }
    }
}

