import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import Login from '../Account/Login';
import './ManagerDashboard.css'

export default class EmployeeDashboard2 extends Component {
    constructor() {
        super();
    }
    logout(){
        sessionStorage.clear();
        window.location="/"
    }
    
    render() {
        let UserName = sessionStorage.getItem("mngname")
        if(sessionStorage.getItem("mngname")!=null){
            return (
                <> 
                    <header>

                        <div class="navbar navbar-dark bg-dark shadow-sm">
                            <div class="container">
                                <a href="#" class="navbar-brand d-flex align-items-center">
                                
                                
                                    <strong>Welcome, {UserName}</strong>
                                    
                                </a>
                                <p> <Card.Link as={Link} to="/Login">
                                <button onClick={this.logout} class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarHeader" aria-controls="navbarHeader" aria-expanded="false" aria-label="Toggle navigation"> Logout
                                    {/* <span class="navbar-toggler-icon"></span> */}
                                </button>
                                </Card.Link>
                                </p>
                                
                            </div>
                        </div>
                    </header>

                    

                        <section class="py-5 text-center container">
                            <div class="row py-lg-5">
                                <div class="col-lg-6 col-md-8 mx-auto">
                                    {/* <h1 class="fw-light">Leave Management System</h1> */}
                                    <h2 class="fw-light">Manager Dashboard</h2>
                                    
                                    {/* <p>
                                        <a href="#" class="btn btn-primary my-2">Main call to action</a>
                                        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
                                    </p> */}
                                </div>
                            </div>
                        </section>

                        <div class="album py-5 bg-light">
                            <div class="container">

                                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-2 g-3">
                                    <div class="col">
                                        <div class="card shadow-sm">
                                            

                                            <div class="card-body">
                                            <h3 id="heading">Employee Section</h3>
                                                <p class="card-text"> Here you can see Employee's details.</p>
                                                <div class="d-flex justify-content-left align-items-center">
                                                    <div class="btn-group">
                                                    <p> <Card.Link as={Link} to="/ViewEmployees">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">View Employees</button>
                                                        </Card.Link></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="card shadow-sm">
                                            

                                            <div class="card-body">
                                            <h3 id="heading">Leave Section</h3>              
                                            <p class="card-text"> Here you can see Employee's pending leave applications.</p>                              
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div class="btn-group">
                                                    <p> <Card.Link as={Link} to="/ApproveDeny">
                                                    <button type="button" class="btn btn-sm btn-outline-secondary">View Pending Leave Applications</button>
                                                        </Card.Link></p>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <footer class="text-muted py-5">
                        <div class="container">
                            {/* <p class="lead text-muted">This LMS project is created by Team-01.</p> */}
                           </div>
                    </footer>
                    </>
            )
        }else{
            alert("Please login first");
            window.location='/'
        }
    }
}
