import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import axios from 'axios'
import ApproveDeny from '../LeaveSection/ApproveDeny'

export default class ManagerLogin extends Component {


  constructor() {
    super();
    this.state = {
      Manager: [],
      mngId: '',
      password: ''
    }
    this.ManagerLogin = this.ManagerLogin.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  ManagerLogin(e) {
    e.preventDefault();
    let mngId = this.state.mngId;
    let password = this.state.password;
    axios.get('https://localhost:44328/api/ManagerInfo/login/' + mngId + '/' + password)
      .then(res => res
      )
      .then(result => {
        console.log(result);
        // sessionStorage.setItem("employee_Id", result.data.employee_Id);
        sessionStorage.setItem("mng", result.data.mngId);
        //alert(result);
        if (result != null) {
          //alert("Valid");

          window.location = "/ApproveDeny";
          sessionStorage.setItem("mngId", mngId)

        }
        else {
          alert("InValid");


        }
      })
      .catch(err => {
        console.log(err);
        alert("Enter valid credentials");



      });
  }
  handleChange(e) {
    this.setState(e);
  }



    render() {
      if(sessionStorage.UserName!=null){
          return (
            <>
            <br/>
            <br/>
            <br/>
            <br/>
            <br/>
              <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">

            <Card >

              <Card.Body>

                <form>

                  <h2>Manager Login</h2>

                  <div className="form-group">
                    <label>Manager ID</label>
                    <input type="number" name='email' onChange={(e) => this.handleChange({ mngId: e.target.value })} className="form-control" placeholder="Enter Manager ID" />
                    <label className="text-muted">
                      We'll never share your data with anyone else.
          </label>
                  </div>

                  <div className="form-group">
                    <label>Password</label>
                    <input type="password" name='password' onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter password" />
                    
                  </div>

                  
                  <br/>
                  <button type="submit" onClick={this.ManagerLogin} className="btn btn-outline-info">Login</button>
                  <br/><br/>
                  <p> <Link as={Link} to="/EmployeeDashboard2">
                      <button type="button" class="btn btn-outline-info">Back</button>
                  </Link></p>
                  

                  


                </form>
              </Card.Body>
            </Card>
          </div>
          </>

          )
      }else{
        alert("Please login first");
        window.location="/Login"
      }
    }
}
