import React, { Component } from 'react'
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';


export default class ManagerDetails extends Component {
  constructor() {
    super();
    this.state = {
      mngId: '',
      mngFullName: '',
      mngEmailAddress: '',
      mngMobileNumber: ''

    }
    this.SearchEmpById = this.SearchEmpById.bind(this);
  }
  SearchEmpById(e) {

    let empId = sessionStorage.getItem("empId");
    axios.get('https://localhost:44328/api/EmployeeInfo/mngdetails?Empid=' + empId)
      .then(response => {
        this.setState({
          mngId: response.data.mngId,
          mngFullName: response.data.mngFullName,
          mngEmailAddress: response.data.mngEmailAddress,
          mngMobileNumber: response.data.mngMobileNumber

        })
      }).catch(error => {
        console.warn(error);
      })
  }
  componentDidMount() {
    this.SearchEmpById()
  }
  render() {

    const { mngId } = this.state;
    const { mngFullName } = this.state;
    const { mngEmailAddress } = this.state;
    const { mngMobileNumber } = this.state;

    if(sessionStorage.UserName != null){
      return (
        <>
          {/* <div>SearchEmpById</div>
              <lable>Enter Employee ID</lable>
              <input type="text" name="employee_Id" defaultValue={employee_Id} onChange={(e)=>this.setState({employee_Id:e.target.value})}></input> 
              <button onClick={(e)=>this.SearchEmpById(e)}>SearchID</button>  */}
          <br></br>
          <label><h1>My Manager Details</h1></label>
          <Table striped bordered hover variant="dark">
        <thead>
          <tr>
            <th>manager Id</th>
            <th>Full Name</th>
            <th>Email Address</th>
            <th>Mobile number</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>{mngId}</th>
            <th>{mngFullName}</th>
            <th>{mngEmailAddress}</th>
            <th>{mngMobileNumber}</th>

          </tr> 
        </tbody>
      </Table>
      <p> <Link as={Link} to="/EmployeeDashboard2">
          <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
          </Link></p>

        </>

      )
    }else{
      alert("Please login first");
      window.location="/Login"
    }
  }
}
