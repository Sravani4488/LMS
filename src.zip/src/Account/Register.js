import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';
import axios from 'axios';
export default class Register extends Component {

    constructor() {
        super();
        this.state = {
            Employee: [],
            empFullName: '',
            empEmailAddress: '',
            empMobileNumber: '',
            empDoj: '',
            department: '',
            password: '',
            availabledays:'0',
            manager_Id: ''

        }
        this.create = this.create.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }
    create() {
        axios.post("https://localhost:44328/api/EmployeeInfo/Add",JSON.stringify({
            empFullName: this.state.empFullName,
            empEmailAddress: this.state.empEmailAddress,
            empMobileNumber: this.state.empMobileNumber,
            empDoj: this.state.empDoj,
            department: this.state.department,
            password: this.state.password,
            managerId: this.state.manager_Id,
            availabledays:this.state.availabledays
        }),{
            headers:{
            "content-type": "application/json",
            "Access-Control-Allow-Origin": "http://localhost:3000",
            'Access-Control-Allow-Credentials': true
        }

        }).
        then(response => {
                alert("Registration Successful.");
                window.location='/Login'
            })
            .catch(err => {
                alert(err);
            })
    }
    handleChange(e) {
        this.setState(e);
    }
    render() {
        return (
            <>
                <br />
                <br />
                <br />
                <br />
                <br />
                <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
                    <Card>
                        <Card.Body>
                            <form>
                                <h2>Register</h2>

                                <div className="form-group">
                                    <label>Employee name</label>
                                    <input type="text" name="full_Name" onChange={(e) => this.handleChange({ empFullName: e.target.value })} className="form-control" placeholder="full_Name" />
                                </div>

                                <div className="form-group">
                                    <label>Email</label>
                                    <input type="email" name="Email" onChange={(e) => this.handleChange({ empEmailAddress: e.target.value })} className="form-control" placeholder="Enter Email" />
                                </div>

                                <div className="form-group">
                                    <label>Phone Number</label>
                                    <input type="text" name="Number" onChange={(e) => this.handleChange({ empMobileNumber: e.target.value })} className="form-control" placeholder="Enter Number" />
                                </div>

                                <div className="form-group">
                                    <label>Date Of Join</label>
                                    <input type="date" name="DOJ" onChange={(e) => this.handleChange({ empDoj: e.target.value })} className="form-control" placeholder="Date of Join" />
                                </div>

                                <div className="form-group">
                                    <label>Department</label>
                                    <input type="text" name="Department" onChange={(e) => this.handleChange({ department: e.target.value })} className="form-control" placeholder="Enter Department" />
                                </div>

                                <div className="form-group">
                                    <label>Password</label>
                                    <input type="password" className="form-control" onChange={(e) => this.handleChange({ password: e.target.value })} placeholder="Enter password" />
                                </div>

                                <div className="form-group">
                                    <label>Manager ID</label>
                                    <input type="text" className="form-control" onChange={(e) => this.handleChange({ manager_Id: e.target.value })} placeholder="Manager ID" />
                                </div>
                                <br/>
                                <button type="submit" onClick={this.create} className="btn btn-outline-info">Register</button>
                                <br/><br/>
                                <p> <Link as={Link} to="/Login">
                                        <button type="button" class="btn btn-outline-info">Back</button>
                                 </Link></p>

                            </form>
                        </Card.Body>
                    </Card>
                </div>
            </>

        )
    }
}
