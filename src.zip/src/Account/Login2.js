import React, { Component } from 'react'
import { Navigate, useNavigate } from 'react-router-dom';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import EmpDash from '../Employee/EmployeeDashboard'
import axios from 'axios'
import { Link } from 'react-router-dom';
import './Login.css';

export default class Login extends Component {

  constructor() {
    super();
    this.state = {
      Employee: [],
      empEmailAddress: '',
      Password: '',
      Manager: [],
      mngEmailAddress: '',
      password: '',
      toggle:true,

    }
    this.Login = this.Login.bind(this);
    this.ManagerLogin = this.ManagerLogin.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  Login(e) {
    e.preventDefault();
    let empEmailAddress = this.state.empEmailAddress;
    let Password = this.state.Password;
    if(empEmailAddress =='' && Password ==''){
        alert("Please Enter Credentials")
    }else if(Password==''){
        alert("Please Enter Password");
    }else if(empEmailAddress==''){
        alert("Please Enter Employee ID")
    }
    else
    {
        axios.get('https://localhost:44328/api/EmployeeInfo/login/' + empEmailAddress + '/' + Password)
        .then(res => res
        )
        .then(result => {
            console.log(result);
            sessionStorage.setItem("empEmailAddress", result.data.empEmailAddress);
            sessionStorage.setItem("password", result.data.password);
            sessionStorage.setItem("mngId", result.data.managerId);
            sessionStorage.setItem("empId", result.data.empId);
            //alert(result);
            if (result != null) {
            //alert("Valid");
            window.location = "/EmployeeDashboard2";
            sessionStorage.setItem("UserName", result.data.empFullName)
            }
            else {
            alert("Invalid");
            }
        })
        .catch(err => {
            console.log(err);
            alert("Enter valid credentials");

        });
    }
  }
 
  ManagerLogin(e) {
    e.preventDefault();
    let mngEmailAddress = this.state.mngEmailAddress;
    let password = this.state.password;
    if(mngEmailAddress == '' && password == ''){
        alert("Please Enter Credentials");
    }else if(password==''){
        alert("Please Enter Password");
    }else if(mngEmailAddress==''){
        alert("Please Enter Manager ID")
    }
    else{
        axios.get('https://localhost:44328/api/ManagerInfo/login/' + mngEmailAddress + '/' + password)
        .then(res => res
        )
        .then(result => {
            console.log(result);
            // sessionStorage.setItem("employee_Id", result.data.employee_Id);
            sessionStorage.setItem("mng", result.data.mngId);
            sessionStorage.setItem("mngname", result.data.mngFullName)
            //alert(result);
            if (result != null) {
            //alert("Valid");
            window.location = "/ManagerDashboard";
            sessionStorage.setItem("mngEmail", mngEmailAddress)
            }
            else {
            alert("InValid");
            }
        })
        .catch(err => {
            console.log(err);
            alert("Enter valid credentials");
        });
    }
  }
  handleChange(e) {
    this.setState(e);
  }

  render() {
    return (
      <>
        <br />
        <br />
        <br />
        <br />
        <br />
        
        <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
          <Card className='logincard'>
            
          <div className='minidashboard'>
                        <button  class="navbarmini" onClick={()=>this.setState(prevState => ({toggle: true}))}>Employee Login</button>
                        <button  class="navbarmini" onClick={()=>this.setState(prevState => ({toggle: false}))}>Manager Login</button>
                                
            </div>   
            {this.state.toggle?
                <Card.Body className='login'>

                <form>

                    {/* <h2 className='header'>Employee Login</h2> */}

                    <div className="form-group">
                    <label className='loginlabel'>Employee Email</label>
                    <input type="Email" name='EmpEmail' onChange={(e) => this.handleChange({ empEmailAddress: e.target.value })} className="form-control" placeholder="Enter Email" />
                    </div>
                    <br></br>
                    <div className="form-group">
                    <label className='loginlabel'>Password</label>
                    <input type="password" name='password' onChange={(e) => this.handleChange({ Password: e.target.value })} className="form-control" placeholder="Enter password" />
                    
                    </div>
                    <br/>

                    <Button type="submit" variant="dark" onClick={this.Login} className="btn btn-outline-info forgpass">Login</Button>
                    {/* <Button type="submit" variant="dark" className="btn btn-outline-info forgpass">Forget Password</Button> */}
                    
                        <p className="Sign_Up text-right"> Forget Password?
                        <Link to="/Testfp">Reset here</Link>
                        </p> 
                   

                    <p className="Sign_Up text-right">
                    Don't have an account yet? <Link to='/Register'>Register</Link>
                    </p>


                </form>
                </Card.Body>
            :
            <Card.Body className='login'>

            <form >

                {/* <h2 className='header'>Manager Login</h2> */}

                <div className="form-group">
                <label className='loginlabel'>Manager Email</label>
                <input type="Email" mngEmail='MngId' onChange={(e) => this.handleChange({ mngEmailAddress: e.target.value })} className="form-control" placeholder="Enter Email" />
                </div>
                <br></br>
                <div className="form-group">
                <label className='loginlabel'>Password</label>
                <input type="password" name='password' onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter password" />
                
                </div>
                <br/>

                <Button type="submit" variant="dark" onClick={this.ManagerLogin} className="btn btn-outline-info forgpass">Login</Button>
                {/* <Button type="submit" variant="dark" onClick={this.forgetpass} className="btn btn-outline-info forgpass">Forget Password</Button> */}
            
                
                    {/* <p className="forgot-password text-right">
                    Forgot <a href="/Testfp">password?</a>
                    </p>  */}
               

                <p className="Sign_Up text-right">
                Don't have an account yet? <Link to='#'>Register</Link>
                </p>


            </form>
            </Card.Body>
            }
            </Card >
        </div>

      </>

    )
  }
}
