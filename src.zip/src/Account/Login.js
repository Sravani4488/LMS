import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import Alert from 'react-bootstrap/Alert';
import EmpDash from '../Employee/EmployeeDashboard'
import axios from 'axios'
import { Link } from 'react-router-dom';
import './Login.css';
export default class Login extends Component {

  constructor() {
    super();
    this.state = {
      Employee: [],
      empId: '',
      Password: '',
      Manager: [],
      mngId: '',
      password: ''
    }
    this.Login = this.Login.bind(this);
    this.ManagerLogin = this.ManagerLogin.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  Login(e) {
    e.preventDefault();
    let empId = this.state.empId;
    let Password = this.state.Password;
    axios.get('https://localhost:44328/api/EmployeeInfo/login/' + empId + '/' + Password)
      .then(res => res
      )
      .then(result => {
        console.log(result);
        sessionStorage.setItem("empId", result.data.empId);
        sessionStorage.setItem("password", result.data.password);
        sessionStorage.setItem("mngId", result.data.managerId);
        //alert(result);
        if (result != null) {
          //alert("Valid");
          window.location = "/EmployeeDashboard2";
          sessionStorage.setItem("UserName", result.data.empFullName)
        }
        else {
          alert("InValid");
        }
      })
      .catch(err => {
        console.log(err);
        alert("Enter valid credentials");

      });
  }
  ManagerLogin(e) {
    e.preventDefault();
    let mngId = this.state.mngId;
    let password = this.state.password;
    axios.get('https://localhost:44328/api/ManagerInfo/login/' + mngId + '/' + password)
      .then(res => res
      )
      .then(result => {
        console.log(result);
        // sessionStorage.setItem("employee_Id", result.data.employee_Id);
        sessionStorage.setItem("mng", result.data.mngId);
        sessionStorage.setItem("mngname", result.data.mngFullName)
        //alert(result);
        if (result != null) {
          //alert("Valid");
          window.location = "/ApproveDeny";
          sessionStorage.setItem("mngId", mngId)
        }
        else {
          alert("InValid");
        }
      })
      .catch(err => {
        console.log(err);
        alert("Enter valid credentials");
      });
  }
  handleChange(e) {
    this.setState(e);
  }

  render() {
    return (
      <>
        <br />
        <br />
        <br />
        <br />
        <br />
        
        <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
          <Card className='logincard'>
            <div>
            <Card.Body>

              <form>

                <h2>Login</h2>

                <div className="form-group">
                  <label>Employee ID</label>
                  <input type="email" name='email' onChange={(e) => this.handleChange({ empId: e.target.value })} className="form-control" placeholder="Enter Employee ID" />
                </div>
                  <br></br>
                <div className="form-group">
                  <label>Password</label>
                  <input type="password" name='password' onChange={(e) => this.handleChange({ Password: e.target.value })} className="form-control" placeholder="Enter password" />
                  
                </div>
                <br/>

                <button type="submit" onClick={this.Login} className="btn btn-outline-info">Login</button>
                {/* 
                    <p className="forgot-password text-right">
                    Forgot <a href="#">password?</a>
                    </p> 
                */}

                <p className="Sign_Up text-right">
                  Don't have an account yet? <Link to='/Register'>Register</Link>
                </p>


              </form>
            </Card.Body>
            </div>
            </Card >
            <Card className='logincard'>
            <div>
            <Card.Body>

              <form>

                <h2>Manager Login</h2>

                <div className="form-group">
                  <label>Manager ID</label>
                  <input type="number" name='email' onChange={(e) => this.handleChange({ mngId: e.target.value })} className="form-control" placeholder="Enter Manager ID" />
                </div>
                <br></br>
                <div className="form-group">
                  <label>Password</label>
                  <input type="password" name='password' onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter password" />
                </div>
                <br/>
                <button type="submit" onClick={this.ManagerLogin} className="btn btn-outline-info">Login</button>
                {
                /* <p className="forgot-password text-right">
                    Forgot <a href="#">password?</a>
                    </p> 
                */
                }

                <p className="Sign_Up text-right">
                  Don't have an account yet? <Link to='/Register'>Register</Link>
                </p>


              </form>
            </Card.Body>
            </div>
          </Card>
        </div>

      </>

    )
  }
}
