import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { Card } from 'react-bootstrap';
import axios from 'axios';
import '../Account/Login.css'

export default class ResetPass extends Component {


  constructor() {
    super();
    this.state = {
        Employee: [],
        empId: '',
        password: '',
        empFullName:'string',
        empEmailAddress:'user@example.com',
        empMobileNumber:'1111111111',
        department:'xxx',
        confirmpassword: ''

    }
    this.create = this.create.bind(this);
    this.handleChange = this.handleChange.bind(this);
}


create(e) {
  e.preventDefault();
    let password = this.state.password;
    let confirmpassword = this.state.confirmpassword;

    if(password!==confirmpassword)
    {
      alert("password match error")
    }
    else{

  axios.put("https://localhost:44328/api/EmployeeInfo/password/"+ this.state.empId, JSON.stringify({
      empId: this.state.empId,
      password: this.state.password,
      empFullName:this.state.empFullName,
      empEmailAddress:this.state.empEmailAddress,
      empMobileNumber:this.state.empMobileNumber,
      department:this.state.department,
  }),{
      headers:{
      "content-type": "application/json",
      "Access-Control-Allow-Origin": "http://localhost:3000",
      'Access-Control-Allow-Credentials': true
  }

  }).
  then(response => {
          alert("Password changed successfully");
          window.location='/Login'
      })
      .catch(err => {
          alert(err);
      })
}}
handleChange(e) {
  this.setState(e);

}
  render() {
    
      return ( <>
        <br />
        <br />
        <br />
        <br />
        <br />
        <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
            <Card>
                <Card.Body>
                    <form>
                        <h2><center>Create new Password</center></h2>

                        <div className="form-group">
                            <label loginlabel>Employee Id</label>
                            <input type="number" name="Id" onChange={(e) => this.handleChange({ empId: e.target.value })} className="form-control" placeholder="Employee Id" />
                        </div>

                        <div className="form-group">
                            <label loginlabel>New Password</label>
                            <input type="password" name="Password" onChange={(e) => this.handleChange({ password: e.target.value })} className="form-control" placeholder="Enter new Password" />
                        </div>

                        <div className="form-group">
                            <label loginlabel>Confirm Password</label>
                            <input type="password" name="Password" onChange={(e) => this.handleChange({ confirmpassword: e.target.value })} className="form-control" placeholder="Confirm Password" />
                        </div>
                    
                        <br/>
                        <button type="submit" onClick={this.create}  className="btn btn-outline-info">Confirm</button>
                        <br/><br/>
                        <p> <Link as={Link} to="/Login">
                                <button type="button" class="btn btn-outline-info">Back</button>
                        </Link></p>

                    </form>
                </Card.Body>
            </Card>
        </div>
      </>
      )
    }
  }


