import React, { Component } from 'react'
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';


export default class SearchEmpById extends Component {
    constructor() {
        super();
        this.state = {
            employee_Id: '',
            full_Name: '',
            email_Address: '',
            mobile_Number: '',
            date_Joined: '',
            department: '',
            password:'',
            availabledays:'',
            managerId:''            
        }
        this.SearchEmpById = this.SearchEmpById.bind(this);
    }
    SearchEmpById(e) {

        let employee_Id = sessionStorage.getItem("empId");
        axios.get('https://localhost:44328/api/EmployeeInfo/details/' + employee_Id)
            .then(response => {
                this.setState({
                    employee_Id: response.data.empId,
                    full_Name: response.data.empFullName,
                    email_Address: response.data.empEmailAddress,
                    mobile_Number: response.data.empMobileNumber,
                    date_Joined: response.data.empDoj,
                    department: response.data.department,
                    password: response.data.password,
                    availabledays: response.data.availabledays,
                    managerId: response.data.managerId
                    
                })
            }).catch(error => {
                console.warn(error);
            })
    }
    componentDidMount() {
        this.SearchEmpById()
    }
    render() {
        // let employee_Id = localStorage.getItem("empId");
        const { full_Name } = this.state;
        const { email_Address } = this.state;
        const { mobile_Number } = this.state;
        const { date_Joined } = this.state;
        const { department } = this.state;
        const { password } = this.state;
        const { availabledays } = this.state;
        const { managerId } = this.state;
        if(sessionStorage.UserName!=null){
                return (
                    <>
                    
                        <br></br>
                        <label><h1>My Details</h1></label>
                        
                        <Table striped bordered hover variant="dark">
            <thead>
                <tr>
                <th>Employee Id</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th>Mobile Number</th>
                <th>Date Joined</th>
                <th>Department</th>
                <th>Password</th>
                <th>Available Leaves</th>
                <th>Manager ID</th>
                
                </tr>
            </thead>
            <tbody>
                <tr>
                
                <td>{this.state.employee_Id}</td>
                <td>{full_Name}</td>
                <td>{email_Address}</td>
                <td>{mobile_Number}</td>
                <td>{date_Joined}</td>
                <td>{department}</td>
                <td>{password}</td>
                <td>{availabledays}</td>
                <td>{managerId}</td>
                
                </tr>
            </tbody>
            </Table>
            <p> <Link as={Link} to="/EmployeeDashboard2">
                <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
                </Link></p>

                    </>

                )
        }else{
            alert("Please login first");
            window.location="/Login"
        }
    }
}