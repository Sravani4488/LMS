import {React,useState,useEffect} from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Table from 'react-bootstrap/Table';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios'

export default function DeleteEmployee(props) {
  const params= useParams();
  const{id} = params;


  const [AllEmployees, employees] = useState({
    empId:"",
    empFullName:"",
    empEmailAddress:"",
    empMobileNumber:"",
    empDoj:"",
    department:"",
    availabledays:"",
    managerId:""
  });

  const {empId,empFullName,empEmailAddress,empMobileNumber,empDoj,department,availabledays,managerId}=AllEmployees;


  useEffect(()=>{

    axios.get("https://localhost:44328/api/EmployeeInfo/details/"+id).
    then(result=>employees(result.data))
  
      
  },[])
const Delete = async e => {
  e.preventDefault();
   await axios.delete("https://localhost:44328/api/EmployeeInfo/delete/"+id).
   then(result=>{
    alert("Employee details deleted.")
     window.location="/ViewEmployees";
   });
  
 };
if(sessionStorage.mngname !=null){
      return (
        <div>
            <>
    <label><h1>Delete Employee</h1></label>
    <Table striped bordered hover variant="dark">
    <thead>
      <tr>
        <th>Employee Id</th>
        <th>Full Name</th>
        <th>Email Address</th>
        <th>Mobile Number</th>
        <th>Date Joined</th>
        <th>Department</th>
        <th>Available Leaves</th>
        <th>Manager ID</th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <td>{empId}</td>
        <td>{empFullName}</td>
        <td>{empEmailAddress}</td>
        <td>{empMobileNumber}</td>
        <td>{empDoj}</td>
        <td>{department}</td>
        <td>{availabledays}</td>
        <td>{managerId}</td>
      </tr>
    </tbody>

    </Table>
    <br/>
    <br/>
    <br/>

    <Button variant="secondary" onClick={Delete} >Delete</Button>
    <br/>
    <br/>
    <p> <Link as={Link} to="/ViewEmployees">
    <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
    </Link></p>

    </>
            
        </div>
    )
  }else{
    alert("Please login first");
    window.location="/Login"
  }
}
