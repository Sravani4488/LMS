import React, { Component } from 'react'
import Card from 'react-bootstrap/Card';
import { Link } from 'react-router-dom';


export default class EmployeeDashboard extends Component {
  constructor() {
    super();
  }
  render() {
    let UserName = localStorage.getItem("UserName");
    if(sessionStorage.UserName !=null){
      return (
        <>
          <h1 text-allign>Welcome {UserName}</h1>

          <body>

            <h1 id="heading">Employees Dashboard Section</h1>
            <br></br>
              <div className="row">
              <div className="column">
                <div className="container card text-white bg-dark" id="card1">
                  <div className="card-body">
                  <label>My Details Section</label>
                    <p><h4> <Card.Link as={Link} to="/EmpDetails">View Details</Card.Link></h4></p>

                  </div>
                </div>
              </div>
              <div className="column">
                <div className="container card text-white bg-dark" id="card2">
                  <div className="card-body">
                    <label> My Manager Details section</label>
                    <p><Card.Link as={Link} to="/ManagerDetails">View Details</Card.Link></p>
                  </div>
                </div>

              </div>

            </div>


            <div className="row">
              <div className="column">

                <div className="container card text-white bg-dark" id="card3">
                  <div className="card-body">
                  <label>Leave Section</label>
                    <p> <Card.Link as={Link} to="/LeaveDetails">Apply Now</Card.Link></p>
                  </div>
                </div>
              </div>

              <div className="column">

                <div className="container card text-white bg-dark" id="card4">
                  <div className="card-body">
                  <label>My Reporting Employees Pending Leave Applications</label>
                    <p><Card.Link as={Link} to="/ApproveDeny">View Application</Card.Link></p>
                    <Link to ="/ApproveDeny">
                    <button onClick={Link}  className="btn btn-outline-info mx-2">dfgeddd</button>
                    </Link>
                  </div>
                </div>

              </div>

            </div> 
            


          </body>
        </>
      )
    }else{
      alert("Please login first");
      window.location="/Login"
    }
  }
}
