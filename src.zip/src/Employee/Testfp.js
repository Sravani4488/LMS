import React, { useEffect, useState, useRef } from "react";
import axios from 'axios'
import emailjs from 'emailjs-com';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import '../Account/Login.css'
import { useNavigate } from "react-router-dom";

export default function Testfp() {
    const form = useRef();
    const [otp,setotp]=useState('');
    const [msg, setMessage] = useState('');
    const navigate = useNavigate();

    const sendEmail = (e) => {
    e.preventDefault();

    emailjs.sendForm('service_gj5kesy', 'template_edogors', form.current, 'LAYchSD9tgi5qvbCH')
      .then((result) => {
        alert("OTP sent successfully.")
          console.log(result.text);
      }, (error) => {
          console.log(error.text);

      });
  };
  function makeid() {
    var message = '';
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < 5; i++)
      message += possible.charAt(Math.floor(Math.random() * possible.length));
    setotp(message)
  }
  const handleChange = event => {
    setMessage(event.target.value);
}
function authenticate(){
    if(otp===msg){
        navigate('/ResetPass')
    }else{
        alert("Invalid OTP");
        navigate('/Testfp')
    }
}

  return (
    <>
    <div class="row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4">
          <Card className='logincard'>
            
          <div className='minidashboard'>
                        <button  class="navbarmini">Forget Password</button>
                                
            </div>
                <Card.Body className='login'>

                <form ref={form} onSubmit={sendEmail}>

                    {/* <h2 className='header'>Employee Login</h2> */}
                
                    <div className="form-group">
                    <label className='loginlabel'>Employee Email</label>
                    <input type="Email" name='to_email' className="form-control" placeholder="Enter Email" />
                    <input type="hidden" name='message' value={otp} className="form-control"/>
                    <Button type="submit" variant="dark" onClick={makeid} className="btn btn-outline-info forgpass">Send OTP</Button>
                    </div>
                
                    <div className="form-group">
                    <label className='loginlabel'>OTP</label>
                    <input type="password" name='password' value={msg} onChange={(e)=>handleChange(e)} className="form-control" placeholder="Enter OTP" />
                    
                    </div>
                    
                </form>
                <Button type="submit" variant="dark" onClick={authenticate} className="btn btn-outline-info forgpass">Submit</Button>
                </Card.Body>
            </Card>
        </div>
    </>
  )
}
