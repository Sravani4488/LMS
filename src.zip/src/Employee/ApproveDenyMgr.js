import {React,useState,useEffect} from 'react'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Table from 'react-bootstrap/Table';
import { Link, useParams } from 'react-router-dom';
import axios from 'axios'

export default function ApproveDenyMgr(props) {
  const params= useParams();
  const{id} = params;


  const [pendingLeave, setpendingLeave] = useState({
    leaveId:"",
    employeeId:"",
    noofDays:"",
    startDate:"",
    endDate:"",
    leaveType:"",
    status:"",
    reason:"",
    managerComments:""
  });

  const {leaveId,employeeId,noofDays,startDate,endDate,leaveType,status,reason,managerComments}=pendingLeave;


  useEffect(()=>{

    axios.get("https://localhost:44328/api/LeaveInfo/leave/"+id).
    then(result=>setpendingLeave(result.data))
  
      
  },[])


  function getData(val)
{
  setpendingLeave({...pendingLeave, managerComments:val.target.value})
 
}
const Approve = async e => {
  e.preventDefault();
   await axios.put("https://localhost:44328/api/LeaveInfo/leave/"+id+"/approve",{...pendingLeave, status:"Approved"}).
   then(result=>{
     window.location="/ApproveDeny";
   });
  
 };


 const Deny = async e => {
  

  e.preventDefault();
 
  
   await axios.put("https://localhost:44328/api/LeaveInfo/leave/"+id+"/approve",{...pendingLeave, status:"Denied"}).
   then(result=>{
     window.location="/ApproveDeny";
   });
  
 };
if(sessionStorage.mngname !=null){
      return (
        <div>
            <>
    <label><h1>Pending Applications</h1></label>
    <Table striped bordered hover variant="dark">
    <thead>
      <tr>
        <th>Leave ID</th>
        <th>Employee ID</th>
        <th>Number of days</th>
        <th>From date</th>
        <th>To Date</th>
        <th>Leave Type</th>
        <th>Status</th>
        <th>Reason</th>
      </tr>
    </thead>
    <tbody>

      <tr>
        <td>{leaveId}</td>
        <td>{employeeId}</td>
        <td>{noofDays}</td>
        <td>{startDate}</td>
        <td>{endDate}</td>
        <td>{leaveType}</td>
        <td>{status}</td>
        <td>{reason}</td>
      </tr>
    </tbody>

    </Table>
    <br/>
    <br/>

    {/* <InputGroup>
    <InputGroup.Text>Manager comments</InputGroup.Text>
    <Form.Control as="textarea" onChange={getData} aria-label="With textarea" />
    </InputGroup> */}

    <textarea className="form-control" onChange={getData} name="comment"aria-label="With textarea" placeholder="Comments" required></textarea>

    <br/>
    <br/>

    <Button variant="secondary" onClick={Approve} >Approve</Button> <Button variant="secondary" onClick={Deny}>Deny</Button>



    <br/>
    <br/>


    <p> <Link as={Link} to="/ApproveDeny">
    <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
    </Link></p>

    </>
            
        </div>
    )
  }else{
    alert("Please login first");
    window.location="/Login"
  }
}
