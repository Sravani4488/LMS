import React, { Component } from 'react'
import Form from 'react-bootstrap/Form';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import './EmployeeDashboard2.css'



export default class UpdateEmployee extends Component {
    constructor()
    {
        super();
        this.state={
            Employee: [],
            empId:0 ,
            empFullName: '',
            empEmailAddress: '',
            empDoj: '',
            empMobileNumber: '',
            department: '',
            Password: '',
            availabledays: 0,
            managerId: 0,
            manager:{
                mngFullName:'string',
                mngEmailAddress: 'string',
                mngMobileNumber: 0,
                password: 'string'
            }

        }
        this.Update=this.Update.bind(this);
        this.getEmployee=this.getEmployee.bind(this);
    }
    getEmployee(e) {
        let employee_Id = sessionStorage.getItem("empId");
        axios.get('https://localhost:44328/api/EmployeeInfo/details/' + employee_Id)
            .then(response => {
                this.setState({
                    empId: response.data.empId,
                    empFullName: response.data.empFullName,
                    empEmailAddress: response.data.empEmailAddress,
                    empFullName: response.data.empMobileNumber,
                    empDoj: response.data.empDoj,
                    department: response.data.department,
                    Password: response.data.password,
                    availabledays: response.data.availabledays,
                    managerId: response.data.managerId
                    
                })
            }).catch(error => {
                console.warn(error);
            })
    }
    componentDidMount() {
        this.getEmployee()
    }
    handleChange(e)
    {
        this.setState(e);
    }
    Update()
    {
        let employee_Id = sessionStorage.getItem("empId");
        axios.put("https://localhost:44328/api/EmployeeInfo/update/"+employee_Id,JSON.stringify(
        {
            empId:this.state.empId,
            empFullName:this.state.empFullName,
            empEmailAddress:this.state.empEmailAddress,
            empDoj:this.state.empDoj,
            empMobileNumber:this.state.empMobileNumber,
            department:this.state.department,
            Password:this.state.Password,
            availabledays:this.state.availabledays,
            managerId:this.state.managerId,
            manager: this.state.manager
        }),{
            headers:{
                "content-type": "application/json",
                "Access-Control-Allow-Origin": "http://localhost:3000",
                'Access-Control-Allow-Credentials': true
            }
        }).then(response=>{
            console.log(response);
            alert("Data Updated");
            window.location='/Login'
            sessionStorage.clear();
        }).catch(err=>{alert(err);})
    }
  render() {
    const { empFullName } = this.state;
        const { empEmailAddress } = this.state;
        const { empMobileNumber } = this.state;
        const { empDoj } = this.state;
        const { department } = this.state;
        const { Password } = this.state;
        const { availabledays } = this.state;
        const { managerId } = this.state;
    if(sessionStorage.getItem("empId")){
        return (
            
            <>
            <div class="row justify-content-center row row-cols-1 row-cols-sm-1 row-cols-md-2 g-4"row justify-content-center>
            <Form>

            <label><h1 >Update Details</h1></label>
            <Form.Group className="mb-3" controlId="formBasicStartDate">
                <Form.Label className='label'>Name</Form.Label>
                <Form.Control required type="text" onChange={(e) => this.handleChange({ empFullName: e.target.value })} placeholder="Your name" />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicEndDate">
                <Form.Label>Email</Form.Label>
                <Form.Control requiredmtype="Email" onChange={(e) => this.handleChange({ empEmailAddress: e.target.value })} placeholder="Your Email" />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicnumber_of_Days">
                <Form.Label>Department</Form.Label>
                <Form.Control required type="text" onChange={(e) => this.handleChange({ department: e.target.value })} placeholder="Your Department" />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicmobile">
                <Form.Label>Mobile No</Form.Label>
                <Form.Control required type="tel" onChange={(e) => this.handleChange({ empMobileNumber: e.target.value })} placeholder="Phone No" />

            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicpassword">
                <Form.Label>Password</Form.Label>
                <Form.Control required type="password" onChange={(e) => this.handleChange({ Password: e.target.value })} placeholder="Password" />
            </Form.Group>

            <Button variant="primary" onClick={()=>this.Update()}>
                Update
            </Button>
            <br/><br/>
            <p> <Link as={Link} to="/EmployeeDashboard2">
            <Button variant="primary" type="Submit" >
                Back
            </Button>
            </Link></p>
            </Form >
            </div>
            </>
        )
    }else{
        alert("Please login first");
        window.location='/Login';
    }
  }
}
