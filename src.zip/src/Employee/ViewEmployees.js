import React, { Component } from 'react'
import axios from 'axios'
import Table from 'react-bootstrap/Table';
import { Link } from 'react-router-dom';


export default class ViewEmployees extends Component {
    constructor() {
        super();
        this.state={
            AllEmployee:[]
        }
    }
    componentDidMount() {
        let mngid = sessionStorage.getItem("mng")
        axios.get('https://localhost:44328/api/EmployeeInfo/showallemployee?mngid='+mngid).then(Response=>{
            this.setState({AllEmployee:Response.data})
        }).catch(error=>{
           console.warn(error); 
        })
    }
    
    render() {
        const {AllEmployee}=this.state;
       
        // if(sessionStorage.UserName!=null){
                return (
                    <>
                    
                        <br></br>
                        <label><h1>Employee Details</h1></label>
                        
                        <Table striped bordered hover variant="dark">
            <thead>
                <tr>
                <th>Employee Id</th>
                <th>Full Name</th>
                <th>Email Address</th>
                <th>Mobile Number</th>
                <th>Date Joined</th>
                <th>Department</th>
                <th>Available Leaves</th>
                <th>Manager ID</th>
                {/* <th>Action 1</th> */}
                <th>Delete Employee</th>
                
                </tr>
            </thead>
            <tbody>
                {
                    AllEmployee.map(a=>
                
                <tr>
                
                <td>{a.empId}</td>
                <td>{a.empFullName}</td>
                <td>{a.empEmailAddress}</td>
                <td>{a.empMobileNumber}</td>
                <td>{a.empDoj}</td>
                <td>{a.department}</td>
                <td>{a.availabledays}</td>
                <td>{a.managerId}</td>
                {/* <td> <p> <Link to={"/UpdateEmployeeMgr/"+a.empId}>
                  <button type="button" class="btn btn-outline-info">Update</button>
                  </Link></p></td> */}
                 <td>  <p> <Link to={"/DeleteEmployee/"+a.empId}>
                  <button type="button" class="btn btn-outline-info">Delete</button>
                  </Link></p></td>
                
                </tr>
   ) }
            </tbody>
            </Table>
            <p> <Link as={Link} to="/ManagerDashboard">
                <button type="button" class="btn btn-sm btn-outline-secondary">Back</button>
                </Link></p>

                    </>

                )
        // }else{
        //     window.location="/ManagerLogin"
        // }
    }
}