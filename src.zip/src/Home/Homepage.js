import React from 'react'
import { Link } from 'react-router-dom';
import "./Homepage.css";
import { Button } from 'react-bootstrap';

export default function Homepage() {
  return (
    <>
    <div><br/><br/><br/><br/><h1 class="fw-light">LEAVE MANAGEMENT SYSTEM</h1></div>
    <br/>
    <div className='b'><h3>Batch-2</h3></div>
    <div className='b'><h3>(Team-1)</h3></div>
    <br/><br/><br/>
    <div><p className="a">
    <Link to='/Login' style={{ textDecoration: 'none' }}><h4>LOGIN</h4></Link>
    {/* <Button type="submit" variant="dark" onClick={this.Login} className="btn btn-outline-info forgpass">Login</Button> */}
    </p>
    </div>
    <br/>
    </>
)
}
